#Excercise1
myString = "This is a string."
print(myString)
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))
#Excercise2
firstString = "water"
secondString = "fall"
thirdString = firstString + secondString
print(thirdString)
#Excercise3
name = input("Siapa nama Anda? ")
print(name)
#Excercise4
animal = input("Apa hewan kesukaan Anda? ")
color = input("Apa warna kesukaan Anda? ")
print("{}, Kamu suka {} {}!".format(name,animal,color))

