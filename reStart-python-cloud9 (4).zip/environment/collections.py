#Exercise1
myFruitList = ["apel", "pisang", "melon"]
print(myFruitList)
print(type(myFruitList))
print(myFruitList[0])
print(myFruitList[1])
print(myFruitList[2])
myFruitList[2] = "jeruk"
print(myFruitList)
#Exercise2
myFinalAnswerTuple = ("apel", "pisang", "semangka")
print(myFinalAnswerTuple)
print(type(myFinalAnswerTuple))
print(myFinalAnswerTuple[0])
print(myFinalAnswerTuple[1])
print(myFinalAnswerTuple[2])
#Excercise3
myFavoriteFruitDictionary = {
    "Hijau" : "apel",
    "Kuning" : "pisang",
    "Merah" : "semangka"
}
print(myFavoriteFruitDictionary)
print(type(myFavoriteFruitDictionary))
print(myFavoriteFruitDictionary["Hijau"])
print(myFavoriteFruitDictionary["Kuning"])
print(myFavoriteFruitDictionary["Merah"])